import java.io.*;
import java.util.*;

public class Main {

    // ================= EXCEPTION =================
    static class InvalidDataException extends Exception {
        public InvalidDataException(String msg) {
            super(msg);
        }
    }

    // ================= INTERFACE =================
    interface Savable {
        void saveToFile();
    }

    // ================= ABSTRACT CLASS =================
    static abstract class Person {
        protected int id;
        protected String name;
        protected int age;
        protected String gender;

        public Person(int id, String name, int age, String gender)
                throws InvalidDataException {

            if (name == null || name.trim().isEmpty())
                throw new InvalidDataException("Name cannot be empty");

            if (age <= 0)
                throw new InvalidDataException("Invalid age");

            this.id = id;
            this.name = name;
            this.age = age;
            this.gender = gender;
        }

        public abstract void displayInfo();
    }

    // ================= PATIENT =================
    static class Patient extends Person implements Savable {

        private String disease;
        private String bloodGroup;

        private ArrayList<Appointment> appointments = new ArrayList<>();

        public Patient(int id, String name, int age, String gender,
                       String disease, String bloodGroup)
                throws InvalidDataException {

            super(id, name, age, gender);

            this.disease = disease;
            this.bloodGroup = bloodGroup;
        }

        public void addAppointment(Appointment a) {
            appointments.add(a);
        }

        @Override
        public void displayInfo() {
            System.out.println("Patient: " + name + " | Disease: " + disease);
        }

        public String toData() {
            return id + "," + name + "," + age + "," + gender + "," + disease + "," + bloodGroup;
        }

        @Override
        public void saveToFile() {
            try (FileWriter fw = new FileWriter("patients.txt", true)) {
                fw.write(toData() + "\n");
            } catch (Exception e) {
                System.out.println("Error saving patient");
            }
        }
    }

    // ================= DOCTOR (AGGREGATION WITH HOSPITAL) =================
    static class Doctor extends Person {

        private String specialization;
        private int experience;
        private double fee;

        private ArrayList<Appointment> appointments = new ArrayList<>();

        public Doctor(int id, String name, int age, String gender,
                      String specialization, int experience, double fee)
                throws InvalidDataException {

            super(id, name, age, gender);

            this.specialization = specialization;
            this.experience = experience;
            this.fee = fee;
        }

        public void addAppointment(Appointment a) {
            appointments.add(a);
        }

        public double getFee() {
            return fee;
        }

        @Override
        public void displayInfo() {
            System.out.println("Doctor: " + name + " | Specialization: " + specialization);
        }
    }

    // ================= APPOINTMENT (ASSOCIATION + INTERFACE) =================
    static class Appointment implements Savable {

        private Patient patient;
        private Doctor doctor;
        private String date;

        public Appointment(Patient patient, Doctor doctor, String date) {

            this.patient = patient;
            this.doctor = doctor;
            this.date = date;

            // Association linking
            patient.addAppointment(this);
            doctor.addAppointment(this);
        }

        public String toData() {
            return patient.name + "," + doctor.name + "," + date;
        }

        @Override
        public void saveToFile() {
            try (FileWriter fw = new FileWriter("appointments.txt", true)) {
                fw.write(toData() + "\n");
            } catch (Exception e) {
                System.out.println("Error saving appointment");
            }
        }
    }

    // ================= COMPOSITION (BILLING + BILLITEM) =================
    static class BillItem {
        private String name;
        private double amount;

        public BillItem(String name, double amount) {
            this.name = name;
            this.amount = amount;
        }

        public double getAmount() {
            return amount;
        }

        public String getName() {
            return name;
        }
    }

    static class Billing {

        private String patientName;
        private ArrayList<BillItem> items;

        public Billing(String patientName) {
            this.patientName = patientName;

            // Composition (strong dependency)
            items = new ArrayList<>();
            items.add(new BillItem("Doctor Fee", 1000));
            items.add(new BillItem("Lab Test", 500));
        }

        public double total() {
            double sum = 0;
            for (BillItem b : items) {
                sum += b.getAmount();
            }
            return sum;
        }

        public void printBill() {
            System.out.println("\n--- BILL ---");
            System.out.println("Patient: " + patientName);

            for (BillItem b : items) {
                System.out.println(b.getName() + " : " + b.getAmount());
            }

            System.out.println("Total: " + total());
        }
    }

    // ================= AGGREGATION (HOSPITAL) =================
    static class Hospital {

        private String name;
        private ArrayList<Doctor> doctors;

        public Hospital(String name) {
            this.name = name;
            doctors = new ArrayList<>();
        }

        public void addDoctor(Doctor d) {
            doctors.add(d);
        }

        public void showDoctors() {
            System.out.println("\nDoctors in " + name + ":");
            for (Doctor d : doctors) {
                d.displayInfo();
            }
        }
    }

    // ================= FILE SEARCH =================
    static class FileManager {

        public static void searchPatient(String name) {
            try {
                File file = new File("patients.txt");

                if (!file.exists()) {
                    System.out.println("No file found");
                    return;
                }

                Scanner sc = new Scanner(file);
                boolean found = false;

                while (sc.hasNextLine()) {
                    String line = sc.nextLine();

                    if (line.toLowerCase().contains(name.toLowerCase())) {
                        System.out.println(line);
                        found = true;
                    }
                }

                if (!found) {
                    System.out.println("Patient not found");
                }

                sc.close();

            } catch (Exception e) {
                System.out.println("File error");
            }
        }
    }

    // ================= MAIN =================
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        try {

            Patient p = new Patient(1, "Ahmed", 25, "Male", "Fever", "O+");
            Doctor d = new Doctor(101, "Ali", 40, "Male", "Cardiology", 10, 1000);

            Hospital h = new Hospital("City Hospital");
            h.addDoctor(d);

            Appointment a = new Appointment(p, d, "12-06-2026");

            while (true) {

                System.out.println("\n===== HOSPITAL SYSTEM =====");
                System.out.println("1. Save Patient");
                System.out.println("2. Search Patient");
                System.out.println("3. Book Appointment");
                System.out.println("4. Show Doctors (Aggregation)");
                System.out.println("5. Generate Bill (Composition)");
                System.out.println("6. Exit");

                System.out.print("Enter choice: ");
                int choice = sc.nextInt();
                sc.nextLine();

                if (choice == 1) {
                    p.saveToFile();
                    System.out.println("Patient Saved");
                }

                else if (choice == 2) {
                    System.out.print("Enter name: ");
                    String name = sc.nextLine();
                    FileManager.searchPatient(name);
                }

                else if (choice == 3) {
                    a.saveToFile();
                    System.out.println("Appointment Saved");
                }

                else if (choice == 4) {
                    h.showDoctors();
                }

                else if (choice == 5) {
                    Billing b = new Billing(p.name);
                    b.printBill();
                }

                else if (choice == 6) {
                    System.out.println("Exiting...");
                    break;
                }

                else {
                    System.out.println("Invalid choice");
                }
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        sc.close();
    }
}