import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class Main {

    // ================= FRAME =================
    JFrame frame;

    JTextField idField, nameField, ageField, genderField, diseaseField, bloodField;
    JTextArea outputArea;

    public Main() {

        frame = new JFrame("Hospital Management System");
        frame.setSize(600, 500);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Labels
        JLabel l1 = new JLabel("ID:");
        JLabel l2 = new JLabel("Name:");
        JLabel l3 = new JLabel("Age:");
        JLabel l4 = new JLabel("Gender:");
        JLabel l5 = new JLabel("Disease:");
        JLabel l6 = new JLabel("Blood Group:");

        l1.setBounds(20, 20, 100, 25);
        l2.setBounds(20, 50, 100, 25);
        l3.setBounds(20, 80, 100, 25);
        l4.setBounds(20, 110, 100, 25);
        l5.setBounds(20, 140, 100, 25);
        l6.setBounds(20, 170, 100, 25);

        frame.add(l1);
        frame.add(l2);
        frame.add(l3);
        frame.add(l4);
        frame.add(l5);
        frame.add(l6);

        // Text Fields
        idField = new JTextField();
        nameField = new JTextField();
        ageField = new JTextField();
        genderField = new JTextField();
        diseaseField = new JTextField();
        bloodField = new JTextField();

        idField.setBounds(130, 20, 150, 25);
        nameField.setBounds(130, 50, 150, 25);
        ageField.setBounds(130, 80, 150, 25);
        genderField.setBounds(130, 110, 150, 25);
        diseaseField.setBounds(130, 140, 150, 25);
        bloodField.setBounds(130, 170, 150, 25);

        frame.add(idField);
        frame.add(nameField);
        frame.add(ageField);
        frame.add(genderField);
        frame.add(diseaseField);
        frame.add(bloodField);

        // Buttons
        JButton addBtn = new JButton("Add Patient");
        JButton searchBtn = new JButton("Search Patient");
        JButton aiBtn = new JButton("AI Check");

        addBtn.setBounds(320, 20, 200, 30);
        searchBtn.setBounds(320, 60, 200, 30);
        aiBtn.setBounds(320, 100, 200, 30);

        frame.add(addBtn);
        frame.add(searchBtn);
        frame.add(aiBtn);

        // Output Area
        outputArea = new JTextArea();
        outputArea.setBounds(20, 220, 540, 220);
        frame.add(outputArea);

        // ================= ACTIONS =================

        addBtn.addActionListener(e -> savePatient());

        searchBtn.addActionListener(e -> searchPatient());

        aiBtn.addActionListener(e -> aiCheck());

        frame.setVisible(true);
    }

    // ================= SAVE PATIENT =================
    void savePatient() {

        try {
            String data = idField.getText() + "," +
                    nameField.getText() + "," +
                    ageField.getText() + "," +
                    genderField.getText() + "," +
                    diseaseField.getText() + "," +
                    bloodField.getText();

            FileWriter fw = new FileWriter("patients.txt", true);
            fw.write(data + "\n");
            fw.close();

            outputArea.setText("Patient Saved Successfully!");

        } catch (Exception e) {
            outputArea.setText("Error saving patient");
        }
    }

    // ================= SEARCH PATIENT =================
    void searchPatient() {

        try {
            File file = new File("patients.txt");
            Scanner sc = new Scanner(file);

            String search = nameField.getText();
            boolean found = false;

            String result = "";

            while (sc.hasNextLine()) {

                String line = sc.nextLine();

                if (line.toLowerCase().contains(search.toLowerCase())) {
                    result += line + "\n";
                    found = true;
                }
            }

            sc.close();

            if (found)
                outputArea.setText(result);
            else
                outputArea.setText("Patient not found");

        } catch (Exception e) {
            outputArea.setText("Error reading file");
        }
    }

    // ================= SIMPLE AI =================
    void aiCheck() {

        String symptom = diseaseField.getText().toLowerCase();

        if (symptom.contains("fever")) {
            outputArea.setText("AI Suggestion: Viral Infection");
        }
        else if (symptom.contains("cough")) {
            outputArea.setText("AI Suggestion: Flu/Cold");
        }
        else if (symptom.contains("pain")) {
            outputArea.setText("AI Suggestion: General Checkup Needed");
        }
        else {
            outputArea.setText("AI Suggestion: Consult Doctor");
        }
    }

    // ================= MAIN =================
    public static void main(String[] args) {
        new Main();
    }
}